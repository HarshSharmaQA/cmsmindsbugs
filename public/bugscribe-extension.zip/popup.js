document.addEventListener("DOMContentLoaded", () => {
    // Load previously saved settings
    chrome.storage.local.get(["bugscribeProjectId", "bugscribeApiKey"], (result) => {
        if (result.bugscribeProjectId) {
            document.getElementById("projectId").value = result.bugscribeProjectId;
        }
        if (result.bugscribeApiKey) {
            document.getElementById("apiKey").value = result.bugscribeApiKey;
        }
    });

    // Save settings
    document.getElementById("saveBtn").addEventListener("click", () => {
        const projectId = document.getElementById("projectId").value;
        const apiKey = document.getElementById("apiKey").value;

        chrome.storage.local.set({
            bugscribeProjectId: projectId,
            bugscribeApiKey: apiKey
        }, () => {
            // Show saved message
            const msg = document.getElementById("savedMsg");
            msg.style.display = "block";
            setTimeout(() => {
                msg.style.display = "none";
            }, 2000);
        });
    });
});

