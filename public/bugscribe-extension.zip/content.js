// BugScribe Content Script Wrapper
function injectWidget() {
    chrome.storage.local.get(["bugscribeProjectId", "bugscribeApiKey"], (refs) => {
        if (!refs.bugscribeProjectId || !refs.bugscribeApiKey) {
            console.log("BugScribe Ext: No project credentials set. Click the extension icon to setup.");
            return;
        }

        // Do not inject if already running
        if (document.getElementById("bugscribe-injected-script")) return;

        // We fetch the main widget bundle dynamically from the local dev server (or production URL eventually)
        // To match your environment, we point to localhost:3001
        const script = document.createElement("script");
        script.id = "bugscribe-injected-script";
        script.src = "http://localhost:3001/widget.js";
        script.async = true;
        script.setAttribute("data-project-id", refs.bugscribeProjectId);
        script.setAttribute("data-api-key", refs.bugscribeApiKey);

        document.head.appendChild(script);
        console.log("BugScribe Ext: Successfully injected widget into context.");
    });
}

// On page load, attempt injection
injectWidget();
