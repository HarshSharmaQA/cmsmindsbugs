console.log("BugScribe Ext: Background Service Worker Active");

// Future logic to handle screenshot capture requests securely, passing messages between activeTabs and BugScribe servers.
